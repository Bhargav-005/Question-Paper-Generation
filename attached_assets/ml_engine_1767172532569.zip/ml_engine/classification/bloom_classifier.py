# classification/bloom_classifier.py

from nltk.stem import PorterStemmer


class BloomClassifier:
    def __init__(self):
        self.stemmer = PorterStemmer()

        raw_bloom_verbs = {
            "L1": ["define", "list", "state", "name", "identify"],
            "L2": ["explain", "describe", "summarize", "illustrate", "what"],
            "L3": ["apply", "solve", "use", "demonstrate"],
            "L4": ["analyze", "compare", "differentiate", "examine"],
            "L5": ["evaluate", "justify", "criticize"],
            "L6": ["design", "create", "develop", "formulate"]
        }

        # 🔥 STEM ALL VERBS ONCE (CRITICAL FIX)
        self.bloom_verbs = {
            level: [self.stemmer.stem(v) for v in verbs]
            for level, verbs in raw_bloom_verbs.items()
        }

    def classify(self, tokens: list[str]) -> str:
        for level, stemmed_verbs in self.bloom_verbs.items():
            for verb in stemmed_verbs:
                if verb in tokens:
                    return level

        # fallback
        return "L2"
