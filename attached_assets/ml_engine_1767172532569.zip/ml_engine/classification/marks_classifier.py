# classification/marks_classifier.py

class MarksClassifier:
    def classify(self, bloom_level: str, token_count: int) -> int:
        if bloom_level in ["L1", "L2"]:
            return 2
        elif bloom_level == "L3":
            return 5
        elif bloom_level == "L4":
            return 8
        elif bloom_level in ["L5", "L6"]:
            return 10
        return 5
