# classification/classification_engine.py

from classification.bloom_classifier import BloomClassifier
from classification.marks_classifier import MarksClassifier
from utils.logger import logger


class QuestionClassificationEngine:
    def __init__(self):
        self.bloom = BloomClassifier()
        self.marks = MarksClassifier()

    def classify(self, stage2_output: dict) -> dict:
        logger.info("Starting Stage 4: Question Classification")

        classified_questions = []

        for q in stage2_output["questions"]:
            tokens = q["tokens"]
            bloom_level = self.bloom.classify(tokens)
            marks = self.marks.classify(bloom_level, len(tokens))

            classified_questions.append({
                "question": q["original"],
                "cleaned": q["cleaned"],
                "tokens": tokens,
                "bloom_level": bloom_level,
                "marks": marks
            })

        logger.info("Stage 4 completed successfully")

        return {
            "classified_questions": classified_questions
        }
