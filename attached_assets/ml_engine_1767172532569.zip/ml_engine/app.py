# app.py

from ingestion.syllabus_loader import SyllabusLoader
from ingestion.co_loader import COLoader
from ingestion.question_loader import QuestionLoader
from utils.logger import logger


class IngestionEngine:
    def __init__(self):
        self.syllabus_loader = SyllabusLoader()
        self.co_loader = COLoader()
        self.question_loader = QuestionLoader()

    def run(self, syllabus_text: str, co_text: str, questions: list[str]) -> dict:
        logger.info("Starting Stage 1: Ingestion")

        syllabus_data = self.syllabus_loader.parse(syllabus_text)
        co_data = self.co_loader.parse(co_text)
        question_data = self.question_loader.parse(questions)

        logger.info("Stage 1 completed successfully")

        return {
            "syllabus": syllabus_data,
            "course_outcomes": co_data,
            "questions": question_data
        }
