# utils/exceptions.py

class IngestionError(Exception):
    pass

class ValidationError(IngestionError):
    pass
