# output/paper_formatter.py

class QuestionPaperFormatter:
    def format(self, questions: list[dict]) -> str:
        """
        Converts final selected questions into printable text format
        """

        part_a = []
        part_b = []
        part_c = []

        q_no = 1

        for q in questions:
            line = f"{q_no}. {q['question']}   ({q['marks']} Marks)  [{q['co']}]"
            q_no += 1

            if q["marks"] == 2:
                part_a.append(line)
            elif q["marks"] == 8:
                part_b.append(line)
            elif q["marks"] == 10:
                part_c.append(line)

        paper = []

        paper.append("INSTITUTE NAME")
        paper.append("DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING\n")
        paper.append("Subject: OPERATING SYSTEMS")
        paper.append("Time: 3 Hours\t\tMax Marks: 100\n")

        if part_a:
            paper.append("PART A (Answer ALL questions)")
            paper.append("(Each question carries 2 marks)\n")
            paper.extend(part_a)
            paper.append("\n")

        if part_b:
            paper.append("PART B (Answer ANY THREE questions)")
            paper.append("(Each question carries 8 marks)\n")
            paper.extend(part_b)
            paper.append("\n")

        if part_c:
            paper.append("PART C (Answer ANY ONE question)")
            paper.append("(Each question carries 10 marks)\n")
            paper.extend(part_c)
            paper.append("\n")

        return "\n".join(paper)
