# assembly/blueprint_engine.py

from utils.logger import logger
from utils.exceptions import ValidationError


class BlueprintEngine:
    def assemble(self, question_pools: dict, blueprint: dict) -> dict:
        logger.info("Starting Stage 6: Blueprint Assembly")

        final_paper = []
        violations = []

        for co_id, marks_req in blueprint.items():
            if co_id not in question_pools:
                violations.append(f"{co_id} not found in question pool")
                continue

            for marks, required_count in marks_req.items():
                available = question_pools[co_id].get(int(marks), [])

                if len(available) < required_count:
                    violations.append(
                        f"{co_id}: Required {required_count} questions of {marks} marks, "
                        f"but found {len(available)}"
                    )
                    continue

                # deterministic selection (first N)
                for i in range(required_count):
                    final_paper.append({
                        "co": co_id,
                        "marks": int(marks),
                        "question": available[i]["question"],
                        "bloom_level": available[i]["bloom_level"]
                    })

        if violations:
            logger.warning("Blueprint violations detected")
            return {
                "status": "rejected",
                "violations": violations,
                "allow_fallback": True
            }

        logger.info("Blueprint assembly successful")

        return {
            "status": "success",
            "question_paper": final_paper
        }
    
