# preprocessing/preprocessing_engine.py

from preprocessing.cleaner import TextCleaner
from preprocessing.tokenizer import Tokenizer
from utils.logger import logger


class PreprocessingEngine:
    def __init__(self):
        self.cleaner = TextCleaner()
        self.tokenizer = Tokenizer()

    def process(self, stage1_output: dict) -> dict:
        logger.info("Starting Stage 2: Text Preprocessing")

        syllabus_units = stage1_output["syllabus"]["units"]
        cos = stage1_output["course_outcomes"]["cos"]
        questions = stage1_output["questions"]["questions"]

        processed_syllabus = {}
        for unit, topics in syllabus_units.items():
            processed_syllabus[unit] = []
            for topic in topics:
                cleaned = self.cleaner.clean(topic)
                tokens = self.tokenizer.tokenize(cleaned)

                processed_syllabus[unit].append({
                    "original": topic,
                    "cleaned": cleaned,
                    "tokens": tokens
                })

        processed_cos = {}
        for co_id, description in cos.items():
            cleaned = self.cleaner.clean(description)
            tokens = self.tokenizer.tokenize(cleaned)

            processed_cos[co_id] = {
                "original": description,
                "cleaned": cleaned,
                "tokens": tokens
            }

        processed_questions = []
        for q in questions:
            cleaned = self.cleaner.clean(q)
            tokens = self.tokenizer.tokenize(cleaned)

            processed_questions.append({
                "original": q,
                "cleaned": cleaned,
                "tokens": tokens
            })

        logger.info("Stage 2 completed successfully")

        return {
            "syllabus": processed_syllabus,
            "course_outcomes": processed_cos,
            "questions": processed_questions
        }
