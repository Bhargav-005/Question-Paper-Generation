# preprocessing/cleaner.py

import re
from utils.logger import logger


class TextCleaner:
    def clean(self, text: str) -> str:
        if not text:
            return ""

        logger.debug("Cleaning text")

        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        text = re.sub(r"\s+", " ", text)

        return text.strip()
