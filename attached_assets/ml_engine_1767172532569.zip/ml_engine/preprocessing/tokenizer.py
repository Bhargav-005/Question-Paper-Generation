# preprocessing/tokenizer.py

from nltk.stem import PorterStemmer

class Tokenizer:
    def __init__(self):
        self.stemmer = PorterStemmer()

    def tokenize(self, text: str) -> list[str]:
        if not text:
            return []

        tokens = text.split()
        tokens = [self.stemmer.stem(t) for t in tokens if len(t) > 1]

        return tokens
