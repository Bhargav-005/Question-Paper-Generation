# pooling/co_question_pooler.py

from utils.logger import logger


class COQuestionPooler:
    def __init__(self):
        # fixed marks buckets
        self.marks_buckets = [2, 5, 8, 10]

    def _question_matches_topic(self, question_tokens, topic_tokens) -> bool:
        """
        Simple deterministic overlap check
        """
        return len(set(question_tokens) & set(topic_tokens)) > 0

    def build_pool(
        self,
        stage2_output: dict,
        stage3_output: dict,
        stage4_output: dict
    ) -> dict:
        """
        Build CO-wise question pools bucketed by marks
        """

        logger.info("Starting Stage 5: CO-wise Question Pooling")

        # Initialize CO structure
        co_pools = {}
        for co_id in stage3_output["co_topic_mapping"].keys():
            co_pools[co_id] = {
                m: [] for m in self.marks_buckets
            }

        # Flatten syllabus topics by CO
        co_topics = {}
        for co_id, topics in stage3_output["co_topic_mapping"].items():
            co_topics[co_id] = []
            for t in topics:
                unit = t["unit"]
                topic_name = t["topic"]

                # find topic tokens from stage2
                for topic in stage2_output["syllabus"][unit]:
                    if topic["original"] == topic_name:
                        co_topics[co_id].append(topic)
                        break

        # Process each classified question
        for q in stage4_output["classified_questions"]:
            q_tokens = q["tokens"]
            q_marks = q["marks"]

            for co_id, topics in co_topics.items():
                for topic in topics:
                    if self._question_matches_topic(q_tokens, topic["tokens"]):
                        co_pools[co_id][q_marks].append({
                            "question": q["question"],
                            "marks": q_marks,
                            "bloom_level": q["bloom_level"],
                            "matched_topic": topic["original"]
                        })
                        break  # avoid duplicate insertion

        logger.info("Stage 5 completed successfully")

        return {
            "co_question_pools": co_pools
        }
