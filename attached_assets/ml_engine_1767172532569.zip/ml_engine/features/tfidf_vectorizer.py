# features/tfidf_vectorizer.py

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class TFIDFVectorizer:
    def __init__(self):
        self.vectorizer = TfidfVectorizer()

    def compute_similarity(self, texts_a: list[str], texts_b: list[str]):
        """
        Returns cosine similarity matrix
        """
        corpus = texts_a + texts_b
        tfidf_matrix = self.vectorizer.fit_transform(corpus)

        vec_a = tfidf_matrix[:len(texts_a)]
        vec_b = tfidf_matrix[len(texts_a):]

        return cosine_similarity(vec_a, vec_b)
