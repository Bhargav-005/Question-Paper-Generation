# ingestion/question_loader.py

from config.settings import MIN_QUESTIONS, MAX_QUESTIONS
from utils.exceptions import ValidationError
from utils.logger import logger


class QuestionLoader:
    def parse(self, questions: list[str]) -> dict:
        if not questions or not isinstance(questions, list):
            raise ValidationError("Questions must be a non-empty list")

        cleaned = [q.strip() for q in questions if q.strip()]

        if len(cleaned) < MIN_QUESTIONS:
            raise ValidationError("Not enough sample questions provided")

        if len(cleaned) > MAX_QUESTIONS:
            raise ValidationError("Too many questions provided")

        logger.info(f"Loaded {len(cleaned)} sample questions")

        return {
            "questions": cleaned
        }
