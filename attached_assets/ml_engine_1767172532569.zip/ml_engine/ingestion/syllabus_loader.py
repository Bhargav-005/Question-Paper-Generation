# ingestion/syllabus_loader.py

import re
from utils.exceptions import ValidationError
from utils.logger import logger


class SyllabusLoader:
    def parse(self, syllabus_text: str) -> dict:
        if not syllabus_text or not syllabus_text.strip():
            raise ValidationError("Syllabus text cannot be empty")

        logger.info("Parsing syllabus")

        units = {}
        current_unit = None

        lines = syllabus_text.split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # 🔹 Match UNIT line and capture topics after : or -
            unit_match = re.match(
                r"(UNIT\s*\d+)\s*[:\-]?\s*(.*)",
                line,
                re.IGNORECASE
            )

            if unit_match:
                current_unit = unit_match.group(1).upper()
                units[current_unit] = []

                topics_part = unit_match.group(2)
                if topics_part:
                    topics = [
                        t.strip()
                        for t in re.split(r"[;,]", topics_part)
                        if t.strip()
                    ]
                    units[current_unit].extend(topics)

                continue

            # 🔹 Continuation lines (topics under same UNIT)
            if current_unit:
                topics = [
                    t.strip()
                    for t in re.split(r"[;,]", line)
                    if t.strip()
                ]
                units[current_unit].extend(topics)

        if not units or all(len(v) == 0 for v in units.values()):
            raise ValidationError("No topics detected in syllabus")

        logger.info(f"Parsed syllabus with {len(units)} units")

        return {
            "units": units,
            "raw_text": syllabus_text
        }
