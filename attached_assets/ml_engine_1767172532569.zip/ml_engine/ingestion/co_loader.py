# ingestion/co_loader.py

import re
from config.settings import MAX_COS, MIN_COS
from utils.exceptions import ValidationError
from utils.logger import logger


class COLoader:
    def parse(self, co_text: str) -> dict:
        if not co_text or not co_text.strip():
            raise ValidationError("Course Outcomes cannot be empty")

        logger.info("Parsing Course Outcomes")

        cos = {}
        lines = co_text.split("\n")

        for line in lines:
            line = line.strip()
            match = re.match(r"(CO\d+)\s*[:\-]?\s*(.+)", line, re.IGNORECASE)
            if match:
                co_id = match.group(1).upper()
                description = match.group(2).strip()
                cos[co_id] = description

        if len(cos) < MIN_COS or len(cos) > MAX_COS:
            raise ValidationError(
                f"Invalid number of COs: {len(cos)} (allowed {MIN_COS} or {MAX_COS})"
            )

        logger.info(f"Loaded {len(cos)} Course Outcomes")

        return {
            "cos": cos,
            "raw_text": co_text
        }
