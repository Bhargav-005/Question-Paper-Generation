# mapping/co_syllabus_mapper.py

from features.tfidf_vectorizer import TFIDFVectorizer
from utils.logger import logger


class COSyllabusMapper:
    def __init__(self, threshold: float = 0.35):
        self.tfidf = TFIDFVectorizer()
        self.threshold = threshold

    def token_overlap(self, tokens_a: list[str], tokens_b: list[str]) -> float:
        if not tokens_a or not tokens_b:
            return 0.0

        set_a = set(tokens_a)
        set_b = set(tokens_b)

        return len(set_a & set_b) / len(set_a | set_b)

    def map(self, stage2_output: dict) -> dict:
        logger.info("Starting Stage 3: CO ↔ Syllabus Mapping")

        syllabus_topics = []
        syllabus_meta = []

        for unit, topics in stage2_output["syllabus"].items():
            for t in topics:
                syllabus_topics.append(t["cleaned"])
                syllabus_meta.append({
                    "unit": unit,
                    "original": t["original"],
                    "tokens": t["tokens"]
                })

        co_ids = []
        co_texts = []
        co_tokens = {}

        for co_id, co_data in stage2_output["course_outcomes"].items():
            co_ids.append(co_id)
            co_texts.append(co_data["cleaned"])
            co_tokens[co_id] = co_data["tokens"]

        similarity_matrix = self.tfidf.compute_similarity(
            syllabus_topics, co_texts
        )

        co_topic_map = {co_id: [] for co_id in co_ids}

        for i, topic in enumerate(syllabus_meta):
            for j, co_id in enumerate(co_ids):
                tfidf_score = similarity_matrix[i][j]
                overlap_score = self.token_overlap(
                    topic["tokens"], co_tokens[co_id]
                )

                final_score = 0.6 * tfidf_score + 0.4 * overlap_score


                if final_score >= self.threshold:
                    co_topic_map[co_id].append({
                        "unit": topic["unit"],
                        "topic": topic["original"],
                        "score": round(final_score, 3)
                    })

        logger.info("Stage 3 completed successfully")

        return {
            "co_topic_mapping": co_topic_map,
            "threshold": self.threshold
        }
