# config/settings.py

MAX_COS = 6
MIN_COS = 3

MAX_QUESTIONS = 500
MIN_QUESTIONS = 5
