from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app import IngestionEngine
from preprocessing.preprocessing_engine import PreprocessingEngine
from utils.exceptions import ValidationError
from mapping.co_syllabus_mapper import COSyllabusMapper
from classification.classification_engine import QuestionClassificationEngine
from pooling.co_question_pooler import COQuestionPooler
from assembly.blueprint_engine import BlueprintEngine
from construction.question_constructor import QuestionConstructor
from output.paper_formatter import QuestionPaperFormatter

app = FastAPI(title="ML Engine - Stage 1 & 2")

ingestion_engine = IngestionEngine()
preprocessing_engine = PreprocessingEngine()


# ---------- Request Schema ----------
class IngestionRequest(BaseModel):
    syllabus: str
    course_outcomes: str
    sample_questions: list[str]


# ---------- Stage 1 Endpoint ----------
@app.post("/ingest")
def ingest(request: IngestionRequest):
    try:
        output = ingestion_engine.run(
            syllabus_text=request.syllabus,
            co_text=request.course_outcomes,
            questions=request.sample_questions
        )
        return {"status": "success", "stage": 1, "data": output}

    except ValidationError as ve:
        raise HTTPException(status_code=400, detail=str(ve))


# ---------- Stage 2 Endpoint (🔥 IMPORTANT) ----------
@app.post("/preprocess")
def preprocess(request: IngestionRequest):
    try:
        # 🔹 Stage 1 (dynamic)
        stage1_output = ingestion_engine.run(
            syllabus_text=request.syllabus,
            co_text=request.course_outcomes,
            questions=request.sample_questions
        )

        # 🔹 Stage 2 (dynamic)
        stage2_output = preprocessing_engine.process(stage1_output)

        return {
            "status": "success",
            "stage": 2,
            "data": stage2_output
        }

    except ValidationError as ve:
        raise HTTPException(status_code=400, detail=str(ve))

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

mapper = COSyllabusMapper()


@app.post("/map-co-syllabus")
def map_co_syllabus(request: IngestionRequest):
    try:
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        stage2 = preprocessing_engine.process(stage1)

        stage3 = mapper.map(stage2)

        return {
            "status": "success",
            "stage": 3,
            "data": stage3
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    


classification_engine = QuestionClassificationEngine()


@app.post("/classify-questions")
def classify_questions(request: IngestionRequest):
    try:
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        stage2 = preprocessing_engine.process(stage1)

        stage4 = classification_engine.classify(stage2)

        return {
            "status": "success",
            "stage": 4,
            "data": stage4
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

pooler = COQuestionPooler()


@app.post("/build-question-pools")
def build_question_pools(request: IngestionRequest):
    try:
        # Stage 1
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        # Stage 2
        stage2 = preprocessing_engine.process(stage1)

        # Stage 3
        stage3 = mapper.map(stage2)

        # Stage 4
        stage4 = classification_engine.classify(stage2)

        # Stage 5
        stage5 = pooler.build_pool(stage2, stage3, stage4)

        return {
            "status": "success",
            "stage": 5,
            "data": stage5
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

blueprint_engine = BlueprintEngine()


class BlueprintRequest(IngestionRequest):
    blueprint: dict


@app.post("/assemble-paper")
def assemble_paper(request: BlueprintRequest):
    try:
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        stage2 = preprocessing_engine.process(stage1)
        stage3 = mapper.map(stage2)
        stage4 = classification_engine.classify(stage2)
        stage5 = pooler.build_pool(stage2, stage3, stage4)

        stage6 = blueprint_engine.assemble(
            stage5["co_question_pools"],
            request.blueprint
        )

        return {
            "stage": 6,
            "data": stage6
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


constructor = QuestionConstructor()


@app.post("/assemble-with-fallback")
def assemble_with_fallback(request: BlueprintRequest):
    try:
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        stage2 = preprocessing_engine.process(stage1)
        stage3 = mapper.map(stage2)
        stage4 = classification_engine.classify(stage2)
        stage5 = pooler.build_pool(stage2, stage3, stage4)

        stage6 = blueprint_engine.assemble(
            stage5["co_question_pools"],
            request.blueprint
        )

        # ✅ If blueprint passed, return directly
        if stage6["status"] == "success":
            return {"stage": 6, "data": stage6}

        # 🔁 Otherwise construct missing questions
        stage7 = constructor.construct(
            stage3_output=stage3,
            blueprint=request.blueprint,
            existing_pools=stage5["co_question_pools"]
        )

        return {
            "stage": 7,
            "status": "fallback_used",
            "violations": stage6["violations"],
            "constructed_questions": stage7["constructed_questions"]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

formatter = QuestionPaperFormatter()


@app.post("/generate-print-paper")
def generate_print_paper(request: BlueprintRequest):
    try:
        stage1 = ingestion_engine.run(
            request.syllabus,
            request.course_outcomes,
            request.sample_questions
        )

        stage2 = preprocessing_engine.process(stage1)
        stage3 = mapper.map(stage2)
        stage4 = classification_engine.classify(stage2)
        stage5 = pooler.build_pool(stage2, stage3, stage4)

        stage6 = blueprint_engine.assemble(
            stage5["co_question_pools"],
            request.blueprint
        )

        final_questions = []

        if stage6["status"] == "success":
            final_questions = stage6["question_paper"]
        else:
            stage7 = constructor.construct(
                stage3_output=stage3,
                blueprint=request.blueprint,
                existing_pools=stage5["co_question_pools"]
            )
            final_questions = stage7["constructed_questions"]

        printable = formatter.format(final_questions)

        return {
            "status": "success",
            "printable_question_paper": printable
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


