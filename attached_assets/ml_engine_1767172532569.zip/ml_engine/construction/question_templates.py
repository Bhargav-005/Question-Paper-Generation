# construction/question_templates.py

TEMPLATES = {
    2: {
        "L1": [
            "Define {topic}.",
            "State the concept of {topic}."
        ],
        "L2": [
            "Explain {topic}.",
            "Briefly describe {topic}."
        ]
    },

    5: {
        "L3": [
            "Apply the concept of {topic} with a suitable example.",
            "Demonstrate how {topic} works."
        ]

        
    },

    8: {
        "L4": [
            "Analyze {topic} in detail.",
            "Differentiate {topic} with related concepts."
        ]
    },

    10: {
        "L5": [
            "Evaluate the effectiveness of {topic}.",
            "Critically examine {topic}."
        ],
        "L6": [
            "Design a system based on {topic}.",
            "Develop a solution using {topic}."
        ]
    }
}
