# construction/question_constructor.py

from construction.question_templates import TEMPLATES
from utils.logger import logger


class QuestionConstructor:
    def construct(
        self,
        stage3_output: dict,
        blueprint: dict,
        existing_pools: dict
    ) -> dict:

        logger.info("Starting Stage 7: Dynamic Question Construction")

        constructed_questions = []

        for co_id, marks_req in blueprint.items():
            topics = stage3_output["co_topic_mapping"].get(co_id, [])

            for marks, required in marks_req.items():
                marks = int(marks)
                available = len(existing_pools.get(co_id, {}).get(marks, []))
                missing = required - available

                if missing <= 0:
                    continue

                for i in range(missing):
                    if not topics:
                        continue

                    topic = topics[i % len(topics)]["topic"]

                    # choose safest Bloom level
                    bloom_level = "L2" if marks <= 2 else "L4"

                    template_list = TEMPLATES.get(marks, {}).get(bloom_level, [])
                    if not template_list:
                        continue

                    question_text = template_list[i % len(template_list)].format(
                        topic=topic
                    )

                    constructed_questions.append({
                        "co": co_id,
                        "marks": marks,
                        "question": question_text,
                        "source": "constructed",
                        "topic": topic,
                        "bloom_level": bloom_level
                    })

        logger.info("Stage 7 completed")

        return {
            "constructed_questions": constructed_questions
        }
