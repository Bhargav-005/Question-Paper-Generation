from app import IngestionEngine
from preprocessing.preprocessing_engine import PreprocessingEngine

ingestion = IngestionEngine()
preprocessing = PreprocessingEngine()

stage1_output = ingestion.run(
    syllabus_text="""
    UNIT 1: Introduction to OS, Process Management
    UNIT 2: Memory Management, Virtual Memory
    """,
    co_text="""
    CO1: Understand OS concepts
    CO2: Analyze process scheduling
    CO3: Apply memory management techniques
    """,
    questions=[
        "Define operating system",
        "Explain process scheduling",
        "What is virtual memory?",
        "Differentiate paging and segmentation",
        "Explain round robin scheduling"
    ]
)

stage2_output = preprocessing.process(stage1_output)

print(stage2_output)
